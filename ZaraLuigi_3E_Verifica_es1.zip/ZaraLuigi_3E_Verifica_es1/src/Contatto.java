//enumeratore
enum tipoContratto{abitazione, cellulare, aziendale};

public class Contatto {
    public String nome;
    public String cognome;
    public String telefono;
    public tipoContratto tipo;
    public double  saldo;
    boolean nascosto = false; //variabile che mi dice se il contatto è nascosto oppure no

    //stampa
    public String stampa() {
        return String.format("Nome: %s Cognome: %s Telefono: %s, tipo: %s", nome, cognome, telefono, tipo.toString());
    }

    //stampa contatti nascosti
    public String stampa(boolean mostraNascosto) {
        if(mostraNascosto && nascosto){
            return "Nome: " + nome + ", Cognome: " + cognome + "Telefono: " + telefono + ", tipo: " + tipo.toString() + "(contatto nascosto)";
        }
        return stampa();
    }

    //stampa per il salva file
    //ci permette di scrivere una stringa in un certo modo
    @Override
    public String toString(){
        return String.format("%s; %s; %s, %s", nome, cognome, telefono, tipo.toString() );
    }
}
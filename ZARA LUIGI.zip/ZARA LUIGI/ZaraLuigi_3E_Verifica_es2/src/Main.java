//Zara Luigi
//Classe 3E
//Verifica 14 Maggio 2024 - esercizio 2

/*
Dato un insieme disordinato (della dimensione minima 10 e massima 11 elementi) di numeri interi positivi non ripetuti
(valore minimo 1, valore massimo 30), occorre poter ordinare, in ordine crescente, i soli numeri PARI, lasciando gli
eventuali dispari nella loro posizione originaria, lasciando anche l'ultimo valore (pari o dispari non importa) nella
propria posizione originaria.
*/

//importazione librerie
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //istanzio un oggetto di tipo scanner
        Scanner keyboard = new Scanner(System.in);

        //dichiarazione e inizializzazione delle variabili
        int contPari = 0;
        int qtaN = 0;
        boolean numeroGiaEsistente;

        //chiedo all'utente di inserire in input la quantità di elementi che desidera inserire
        System.out.println("Quanti numeri desidera inserire (min 10 - max 11) ?");

        //controllo qtaN
        do{
            qtaN = keyboard.nextInt();
            if(qtaN < 10 || qtaN > 11){
                System.out.println("valore errato!! riprova:");
            }
        }while(qtaN < 10 || qtaN > 11);

        //istanzio due vettori
        int[] array = new int[qtaN]; //questo vettore contiene i numeri inseriti dall'utente
        int[] numeriPari = new int[qtaN]; //questo vettore conterrà i numeri pari

        //popolo il vettore
        for(int i = 0; i < qtaN; i++){
            int numero;
            do{
                //inizializzo numeroGiaEsistente a false
                numeroGiaEsistente = false;

                //chiedo all'utente di inserire il (i+1) elemento
                System.out.print("Inserisci il "+ (i+1) + " °elemento (min 1 - max 30): ");
                numero = keyboard.nextInt();

                //controllo che il numero inserito sia compreso tra 1 e 30
                if(numero < 1 || numero > 30){
                    System.out.println("Attenzione!! il numero deve essere compreso tra 1 e 30");
                } else {
                    //controllo se il numero è gia presente all'interno dell'array
                    for(int j = 0; j < i; j++){
                        if(array[j] == numero){
                            numeroGiaEsistente = true;
                            break;
                        }
                    }
                }
                if(numeroGiaEsistente){
                    System.out.println("Attenzione!! Il numero inserito è gia presente. Riprova:");
                }
            }while(numero < 1 || numero > 30 || numeroGiaEsistente);
            array[i] = numero;

            //i numeri pari li salvo in un'altro array
            if(numero % 2 == 0){
                numeriPari[contPari++] = numero;
            }
        }

        //invoco il metodo ordinaPari
        ordinaPari(numeriPari, contPari);

        //sostituisco i numeri pari ordinati nell'array originale
        int indicePari = 0;
        for(int i = 0; i < qtaN - 1; i++){
            if(array[i] % 2 == 0){
                array[i] = numeriPari[indicePari++];
            }
        }

        //stampo l'array ordinato
        for(int i = 0; i < qtaN; i++){
            System.out.print(" " + array[i]);
        }
    }

    //algoritmo di ordinamento selection sort
    private static void ordinaPari(int[] numeriPari, int lunghezza){
        for(int i = 0; i < lunghezza - 1; i++){
            int min = i;
            for(int j = i+1; j < lunghezza; j++){
                if(numeriPari[j] < numeriPari[min]){
                    min = j;
                }
            }
            int temp = numeriPari[min];
            numeriPari[min] = numeriPari[i];
            numeriPari[i] = temp;
        }
    }
}
//zara luigi
//classe 3E

/*
Progettare un software che permetta ad un utente di poter gestire la propria rubrica telefonica, permettendo, tramite
l’inserimento di un’apposita password, di visualizzare anche eventuali contatti nascosti.
Tramite un altro metodo appositamente progettato consenta di tornare alla situazione iniziale.

Attenzione:
Un singolo contatto nascosto può essere reso sempre visibile e viceversa.
Occorrerà gestire la lista delle ultime chiamate, in modo che possa essere coerente con quanto sopra richiesto
Scrivere il codice (java-like) di una parte saliente del software, motivandone la scelta.
 */

//importazione tools utility
import static tools.utility.*;

//importazione librerie
import java.awt.*;
import java.io.*;
import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //istanzio un oggetto scanner
        Scanner keyboard = new Scanner(System.in);

        //menu opzioni
        String[] operazioni = {"===RUBRICA TELEFONICA===",
                "[1] - INSERIMENTO",
                "[2] - VISUALIZZAZIONE",
                "[3] - RICERCA",
                "[4] - CANCELLA CONTATTO",
                "[5] - VISUALIZZA IN ORDINE ALFABETICO",
                "[6] - EFFETTUA TELEFONATA",
                "[7] - RICARICA SALDO",
                "[8] - NASCONDI CONTATTO",
                "[9] - SALVA FILE",
                "[10] - CARICA FILE",
                "[11] - IMPOSTAZIONI UTENTE",
                "[12] - FINE"
        };

        //dichiarazione e inizializzazione delle variabili
        boolean Sitel = true;
        final int nMax = 3;
        int contrattiVenduti = 0;
        int posizione;
        boolean fine = true;

        //istanzio un oggetto gestore
        Contatto[] gestore = new Contatto[nMax];
        //istanzio un oggetto di tipo utente
        Utente personalUtente = new Utente();

        //invoco il metodo generaPassword
        String password = generaPassword();

        //registrazione account utente
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║                SIGN UP               ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.print("Inserisci l'username -> ");
        personalUtente.username = keyboard.nextLine();
        System.out.print("password di primo accesso -> " + password + "\n");
        System.out.println("════════════════════════════════════════");

        //pulisci schermo
        //ClrScr();

        do {
            switch (menu(operazioni, keyboard)) {
                case 1: //inserimento
                    if (contrattiVenduti < nMax) {
                        //firma contratto
                        gestore[contrattiVenduti]=leggiPersona(Sitel,keyboard);
                        contrattiVenduti++;
                    } else {
                        System.out.println("Non ci sono più contratti da vendere");
                    }
                    break;
                case 2: //visualizza
                    if(contrattiVenduti!=0){
                        System.out.println("Vuoi visualizzare anche i contatti nascosti (s/n)");
                        boolean visualizzaNascosti = keyboard.nextLine().equalsIgnoreCase("s");
                        visualizza(gestore, contrattiVenduti, visualizzaNascosti);
                    } else {
                        System.out.println("Non sono ancora presenti contratti venduti");
                    }
                    break;
                case 3: //ricerca
                    if(contrattiVenduti !=0){
                        //lettura, ricerca, visualizzazione
                        if(ricerca (gestore,leggiPersona(false, keyboard), contrattiVenduti)){
                            System.out.println("Il contatto esiste");
                        }else{
                            System.out.println("Il contatto non esiste");
                        }
                    }else{
                        System.out.println("Non sono ancora presenti contratti venduti");
                    }
                    break;
                case 4: //cancellazione
                    if (contrattiVenduti != 0) {
                        posizione = RicercaIndex(gestore, leggiPersona(false, keyboard), contrattiVenduti);
                        if (posizione != -1) {
                            contrattiVenduti = cancellazione(gestore, posizione, contrattiVenduti);
                        } else {
                            System.out.println("contatto inesistente");
                        }
                    } else {
                        System.out.println("Non sono ancora presenti contratti venduti");
                    }
                    break;
                case 5: //visualizza in ordine AZ
                    if(contrattiVenduti!=0){
                        visualizzaOrdineAlfabetico(gestore, contrattiVenduti);
                    } else {
                        System.out.println("Non sono ancora presenti contratti venduti");
                    }
                    break;
                case 6: //telefonata
                    posizione = RicercaIndex(gestore, leggiPersona(false, keyboard), contrattiVenduti);
                    if (posizione != -1) {
                        System.out.print("Inserisci il costo della telefonata: ");
                        double costo = keyboard.nextDouble();
                        keyboard.nextLine(); // Pulisci il buffer
                        effettuaTelefonata(gestore[posizione], costo);
                    } else {
                        System.out.println("Contatto inesistente");
                    }
                    break;
                case 7: //saldo
                    posizione = RicercaIndex(gestore, leggiPersona(false, keyboard), contrattiVenduti);
                    if (posizione != -1) {
                        System.out.print("Inserisci l'importo della ricarica: ");
                        double importo = keyboard.nextDouble();
                        keyboard.nextLine(); // Pulisci il buffer
                        ricaricaSaldo(gestore[posizione], importo);
                    } else {
                        System.out.println("Contatto inesistente");
                    }
                    break;
                case 8: //nascondi contatto
                    if(autentificazioneUtente(personalUtente, password, keyboard)){
                        System.out.println("-> credenziali di accesso corrette!");
                        posizione = RicercaIndex(gestore, leggiPersona(false, keyboard), contrattiVenduti);
                        if (posizione != -1) {
                            nascondiContatto(gestore, posizione);
                            System.out.println("-> contatto nascosto con successo :)");
                        } else {
                            System.out.println("il contatto è inesistente");
                        }
                    } else {
                        System.out.println("-> username e/o password errati");
                    }
                    break;
                case 9:
                    // Salvataggio dei contatti su file
                    System.out.println("Vuoi salvare su file anche i contatti nascosti (s/n)");
                    boolean salvaNascosti = keyboard.nextLine().equalsIgnoreCase("s");
                    try {
                        ScriviFile("archivio.csv", gestore, contrattiVenduti, salvaNascosti);
                    } catch (IOException ex) {
                        System.out.println(ex.toString());
                        break;
                    }
                    break;
                case 10:
                    break;
                case 11: //impostazioni utente
                    if(autentificazioneUtente(personalUtente, password, keyboard)){
                        System.out.println("-> credenziali di accesso corrette!");
                        personalUtente.modificaCredenzialiDiAccesso(personalUtente, keyboard);
                    } else {
                        System.out.println("-> credenziali di accesso errate!!!");
                    }
                    break;
                default:
                    fine = false;
                    break;
            }
        } while (fine);
    }

    //metodo leggi persona
    private static Contatto leggiPersona(boolean Sitel, Scanner keyboard) {
        //Sitel è true quando dobbiamo leggere
        String[] tipoC = {"Telefono","1 - abitazione", "2 - cellulare", "3 - aziendale"};
        //Istanziato un oggetto di tipo contatto:
        Contatto persona = new Contatto();
        System.out.print("Inserisci il nome: ");
        persona.nome = keyboard.nextLine();
        System.out.print("Inserisci il cognome: ");
        persona.cognome = keyboard.nextLine();

        if (Sitel) {
            System.out.print("Inserisci il numero di telefono: ");
            persona.telefono = keyboard.nextLine();  //Vado a leggere il numero di telefono

            //new paragraph
            System.out.println();

            //I valori assegnati all'attributo sono compresi nel range
            switch (menu(tipoC, keyboard)) {
                case 1 -> persona.tipo = tipoContratto.abitazione;
                case 2 -> persona.tipo = tipoContratto.cellulare;
                default -> persona.tipo = tipoContratto.aziendale;

            }
        }

        return persona;
    }

    //metodo ricerca contatto
    private static boolean ricerca (Contatto[] gestore, Contatto contatto, int contrattiVenduti){
        //Controllo se il nome e il cognome del contatto e ugale al nome e cogome del gestore
        boolean ricerca = false;

        for(int i = 0; i<contrattiVenduti; i++){
            if(contatto.nome.equals(gestore[i].nome)  && contatto.cognome.equals(gestore[i].cognome)){
                ricerca = true;
            }
        }
        return ricerca;
    }

    //metodo ricercaIndex
    private static int RicercaIndex(Contatto[] gestore, Contatto ricerca, int contrattiVenduti){
        int indice=-1;

        for(int i=0; i < contrattiVenduti; i++){
            if(ricerca.nome.equals(gestore[i].nome)  && ricerca.cognome.equals(gestore[i].cognome)){
                indice=i;
                break;
            }
        }
        return indice;
    }

    /*
    //metodo visualizza
    private static void visualizza(Contatto [] gestore, int contrattiVenduti){
        for(int i=0 ; i<contrattiVenduti; i++){
            System.out.println(gestore[i].stampa());
        }
    }
     */

    /*
    //metodo cancella contatto inserendo il numero di telefono
    private static boolean cancellaPerNumero(Contatto[] gestore, String numeroTelefono, int contrattiVenduti) {
        for (int i = 0; i < contrattiVenduti; i++) {
            if (gestore[i].telefono.equals(numeroTelefono)) {
                for (int j = i; j < contrattiVenduti - 1; j++) {
                    gestore[j] = gestore[j + 1]; //sposta di 1 posizione l'indice
                }
                gestore[contrattiVenduti - 1] = null; //contatto eliminato
                return true;
            }
        }
        return false;
    }
    */

    //metodo cancellazzione contatto
    public static int cancellazione(Contatto[] gestore, int posizione, int contattiVenduti){
        if(posizione !=gestore.length-1)
            for(int i=posizione; i < contattiVenduti-1; i++)
                gestore[i] = gestore[i+1];
        return --contattiVenduti;
    }

    //----------------------------------------------------------------------------------------------------------------//

    //metodo ordina contatti in ordine alfabetico selection sort
    private static void visualizzaOrdineAlfabetico(Contatto[] gestore, int contrattiVenduti){
        //Ordinamento dei contatti in ordine alfabetico per cognome e nome
        for(int i = 0; i < contrattiVenduti - 1; i++){
            for(int j = i+1; j < contrattiVenduti; j++){
                if(gestore[i].cognome.compareTo(gestore[j].cognome) > 0 ||
                        gestore[i].cognome.equals(gestore[j].cognome) && gestore[i].nome.compareTo(gestore[j].nome) > 0){
                    Contatto temp = gestore[i];
                    gestore[i] = gestore[j];
                    gestore[j] = temp;
                }
            }
        }
        //output
        for (int i = 0; i < contrattiVenduti; i++) {
            System.out.println(gestore[i].stampa());
        }
    }

    //Metodo per effettuare una telefonata
    private static void effettuaTelefonata(Contatto contatto, double costo) {
        if (contatto.saldo >= costo) {
            contatto.saldo -= costo;
            System.out.println("Telefonata effettuata. Saldo residuo: " + contatto.saldo);
        } else {
            System.out.println("Saldo insufficiente per effettuare la telefonata.");
        }
    }

    //Metodo per ricaricare il saldo
    private static void ricaricaSaldo(Contatto contatto, double importo) {
        contatto.saldo = contatto.saldo + importo;
        System.out.println("Ricarica effettuata con successo. Saldo attuale: " + contatto.saldo);
    }

    //----------------------------------------------------------------------------------------------------------------//

    //metodo visualizza
    private static void visualizza(Contatto [] gestore, int contrattiVenduti, boolean visualizzaNascosti){
        for(int i=0 ; i<contrattiVenduti; i++){
            if(visualizzaNascosti || !gestore[i].nascosto){
                System.out.println(gestore[i].stampa(visualizzaNascosti));
            }
        }
    }

    //metodo nascondi contatto
    private static void nascondiContatto(Contatto[] gestore, int posizione){
        gestore[posizione].nascosto = true;
    }

    //metodo che genera una password in modo casuale
    public static String generaPassword(){
        //creazione di un oggetto random
        Random random = new Random();

        //Diichiarazione e inizializzazione delle variabili
        int lunghrzzaPw = 8;

        //Caratteri che potrebbero capitare malla password
        String Caratteri = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!£$%&";

        //StringBuilder per costruire la password
        StringBuilder password = new StringBuilder();

        //ciclo for che genera la password in modo casuale
        for(int i = 0; i < lunghrzzaPw; i++){
            //scelta casuale di un carattere
            int index = random.nextInt(Caratteri.length());
            //aggiunta del carattere alla stringa
            password.append(Caratteri.charAt(index));
        }

        //restituisco la password generata
        return password.toString();
    }

    //metodo autentificazione
    public static boolean autentificazioneUtente(Utente personalUtente, String password, Scanner keyboard){
        //Dichiarazione variabili
        String usernameAutentificazione, passwordAutentificazione;

        //autentificazione
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║           AUTENTIFICAZIONE           ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.print("Inserisci l'username -> ");
        usernameAutentificazione = keyboard.nextLine();
        System.out.print("Inserisci la password -> ");
        passwordAutentificazione = keyboard.nextLine();
        System.out.println("════════════════════════════════════════");

        //controllo se l'username e la password inseriti sono uguali a quelle messe durante la fase di sign up
        if(personalUtente.username.equals(usernameAutentificazione) && password.equals(passwordAutentificazione) || personalUtente.password.equals(passwordAutentificazione)){
            return true; //se coincidono allora ritorno true
        } else {
            return false; //se non coincidono allora ritorno false
        }
    }

    //----------------------------------------------------------------------------------------------------------------//

    //metodo per scrivere i contatti su file
    public static void ScriviFile(String fileName, Contatto[] gestore, int contrattiVenduti, boolean salvaNascosti) throws IOException {
        //istanzio un oggetto di tipo writer
        FileWriter writer = new FileWriter(fileName);

        //output
        for (int i = 0; i < contrattiVenduti; i++) {
            if(salvaNascosti || !gestore[i].nascosto){
                writer.write(gestore[i].toString() + "\r\n");
            }
        }

        //svuotiamo il buffer
        writer.flush();

        //fine
        writer.close();
    }
}
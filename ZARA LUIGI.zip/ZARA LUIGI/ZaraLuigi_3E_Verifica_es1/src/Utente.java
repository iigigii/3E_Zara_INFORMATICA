//importazione librerie - package tools
import java.util.Scanner;
import static tools.utility.*;

public class Utente {
    public String username;
    public String password;
    public static String[] operazioniUtente = { "",
            "╔══════════════════════════════════════════╗",
            "║ IMPOSTAZIONI UTENTE                      ║",
            "║   [1] - VISUALIZZA USERNAME - PASSWORD   ║",
            "║   [2] - MODIFICA USERNAME                ║",
            "║   [3] - MODIFICA PASSWORD PREDEFINITA    ║",
            "║   [4] - FINE                             ║",
            "╚══════════════════════════════════════════╝",
    };

    //metodo modifica credenziali contatto
    public static void modificaCredenzialiDiAccesso(Utente personalUtente, Scanner keyboard){
        //dichiarazione e inizializzazione delle variabili
        boolean fineUtenteMenu = true;
        boolean hamodificatopassword = false; //se l'utente ha modificato la password metto la variabile a true

        //invoco il metodo che genera la password
        String password = Main.generaPassword();

        do{
            switch(menu(operazioniUtente, keyboard)){
                case 1:
                    System.out.println("username -> " + personalUtente.username);
                    System.out.println("password predefinita -> " + password);
                    if(hamodificatopassword){
                        System.out.println("password nuova -> " + personalUtente.password);
                    }
                    break;
                case 2:
                    System.out.print("Inserisci il nuovo username: ");
                    personalUtente.username = keyboard.nextLine();
                    break;
                case 3:
                    System.out.print("Inserisci la nuova password: ");
                    personalUtente.password = keyboard.nextLine();
                    hamodificatopassword = true;
                    break;
                default:
                    fineUtenteMenu = false;
                    break;
            }
        }while(fineUtenteMenu);
    }
}
